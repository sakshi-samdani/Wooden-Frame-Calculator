//Ajax Call for fetching SKU list from SKUtable table
document.addEventListener("DOMContentLoaded", function onPageload(){
	var ajax = new XMLHttpRequest();
	var method = "GET";
	var url = "http://192.168.1.5/WoodenFrameCalculator/WoodenFrameCalculator.php"; 
	var asynchronous = true;
	ajax.open( method, url, asynchronous);

	//Sending AJAX request
	ajax.send();

	//Receiving response from http://192.168.1.5/WoodenFrameCalculator/WoodenFrameCalculator.php
	ajax.onreadystatechange = function()
	{
		if( this.readyState == 4 && this.status == 200)
		{
			
			var data = JSON.parse(this.responseText);
			console.log(data);
			var lengthData = Object.keys(data.Data).length;
			console.log(lengthData);
			
			for(var i = 0; i<lengthData; i++)
			{
				var SKUoption = "#00" + data.Data[i].SKUName;
				var SKUoptionactual = data.Data[i].SKUPrice;
				var select = document.getElementById('SKUSelect');
				select.options.add( new Option(SKUoption,SKUoptionactual, true, true) );
				console.log(SKUoption);
			}
		}
	}
});

//When blured from dropdown box OnSelect function is called. SelectedOp is value of price of particular item.
var select = document.getElementById('SKUSelect');
var selectedOp;
select.addEventListener("blur",function OnSelect(){
	selectedOp = select.options[select.selectedIndex].value;
	console.log(selectedOp);
	pricetd= document.getElementById('PriceOne');
	pricetd.innerHTML=selectedOp;
});

//When Calculator button clicked, width and height of the frame is taken and perimeters and price is calculated.
var calbtn = document.getElementById('calbtn');
calbtn.addEventListener("click",function(){
	var width=document.getElementById('width').value;
	var height =document.getElementById('height').value;
	var perval=document.getElementById('perimeter');
	perval.innerHTML=2*width+2*height;
	var pricepf=document.getElementById('OneFramePrice');
	pricepf.innerHTML=selectedOp*(2*width+2*height);
});





