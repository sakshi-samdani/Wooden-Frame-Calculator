<?php
	include "connect.php";
	$arrJson["Data"] = array();
	$query = "SELECT SKUID, SKUName, SKUPrice FROM skutable";
	$result = mysqli_query($connection, $query);
	while($row = mysqli_fetch_assoc($result))
	{
		array_push($arrJson["Data"], $row);
	}
	echo json_encode($arrJson);
?>