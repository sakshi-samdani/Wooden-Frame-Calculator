<?php
	define("PROJECT_NAME","Wooden Frame Calculator");
	define("YEAR","18-19");
	define("SYSTEM_START_DATE","2018-08-25");
	define("SYSTEM_START_MONTH_YEAR","2018-25");
	$connection = mysqli_connect("localhost","root","","woodenframecalculator");
?>
